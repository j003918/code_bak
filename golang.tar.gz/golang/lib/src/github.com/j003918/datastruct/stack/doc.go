// liststack project doc.go

/*
liststack document
*/
package stack
