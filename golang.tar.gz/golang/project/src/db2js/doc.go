// db2js project doc.go

/*
db2js document
*/
package main
