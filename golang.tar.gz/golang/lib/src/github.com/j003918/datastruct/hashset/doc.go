// hashset project doc.go

/*
hashset document
*/
package hashset
