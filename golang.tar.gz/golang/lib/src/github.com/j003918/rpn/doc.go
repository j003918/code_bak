// rpn project doc.go

/*
rpn document
*/
package rpn
