// test project doc.go

/*
test document
*/
package main
